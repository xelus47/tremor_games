var viewportwidth;var viewportheight;if(typeof window.innerWidth!='undefined')
{viewportwidth=window.innerWidth,viewportheight=window.innerHeight}
else if(typeof document.documentElement!='undefined'&&typeof document.documentElement.clientWidth!='undefined'&&document.documentElement.clientWidth!=0)
{viewportwidth=document.documentElement.clientWidth,viewportheight=document.documentElement.clientHeight}
else
{viewportwidth=document.getElementsByTagName('body')[0].clientWidth,viewportheight=document.getElementsByTagName('body')[0].clientHeight}
function popUp(URL){winpops=window.open(URL,"","width=200,height=125,left=100,top=100,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function popUpGame(URL){winpops=window.open(URL,"","width="+viewportwidth+",height="+viewportheight+",left=0,top=0,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function popUp2(URL){winpops=window.open(URL,"","width=200,height =450,left=100,top=100,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function popUpFavorite(URL){winpops=window.open(URL,"","width=200,height=100,left=100,top=100,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function popComments(URL){winpops=window.open(URL,"","width=440,height=400,left=100,top=100,status=0,scrollbars=1,resizable=1,menubar=0,location=0,toolbar=0")}
function popRecoverPassword(URL){winpops=window.open(URL,"","width=440,height=200,left=100,top=100,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function popReportGame(URL){winpops=window.open(URL,"","width=250,height=225,left=100,top=100,status=0,scrollbars=0,resizable=1,menubar=0,location=0,toolbar=0")}
function MM_jumpMenu(targ,selObj,restore){eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");if(restore)selObj.selectedIndex=0;}
function confirmDeleteMessage()
{var agree=confirm("Are you sure you wish to delete this message?");if(agree)
return true;else
return false;}